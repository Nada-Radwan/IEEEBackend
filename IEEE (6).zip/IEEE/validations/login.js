const joi = require('joi')

exports.isValid = (username,password)=>{
    loginSchema = joi.object({
        username:joi.string().min(3).max(45).required(),
        password:joi.string().min(3).max(20).required()
    })

    const loginValidationResult =  loginSchema.validate({username,password })

    if (loginValidationResult.error) {
        return false
    }
    return true
}
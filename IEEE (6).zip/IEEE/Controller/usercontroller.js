const joi = require("joi");
const bcrypt = require("bcrypt");
const adminValidation = require("../validations/admin");
const signupModel = require("../Model/signupmodel");
const multer = require("multer");
const upload = multer({ dest: "signupuploads/" });

const jwt = require("jsonwebtoken");

const knex = require("knex")({
  client: "mysql",
  connection: {
    host: "127.0.0.1",
    port: 3306,
    user: "root",
    password: "123456",
    database: "ieee_db",
  },
});

  

const select = (request, response) => {
  const ieee_id = request.params.ieee_id; //take the id as a paramter
  knex("user")
    .select([
      "uni_id",
      "ieee_id",
      "firstname",
      "secondname",
      "email",
      "username",
      "gender",
    
      "phone_no",
      "faculty",
      "major",
      "level",
      "birthday_date",
      "city",
      "password",
      // "file_name",
      // "file_path",
      // "mime_type",
     
    ])
    .where({
      ieee_id: ieee_id,
    })
    .then((user) => {
      response.status(200).json(user);
    })
    .catch((error) => {
      console.log(error);
    });
};

const create = async (request, response) => {
  const uni_id = request.body.uni_id;
  const ieee_id = request.body.ieee_id;
  const firstname = request.body.firstname;
  const secondname = request.body.secondname;
  const email = request.body.email;
  const username = request.body.username;
  const gender = request.body.gender;

  const phone_no = request.body.phone_no;
  const faculty = request.body.faculty;
  const major = request.body.major;
  const level = request.body.level;
  const birthday_date = request.body.birthday_date;
  const city = request.body.city;
  //const{filename,path,mimetype}=request.file;


  const password = request.body.password;

  const salt = bcrypt.genSaltSync(10);
  const hashpassword = bcrypt.hashSync(password, salt);

  const uservalidate = joi.object({
    uni_id: joi.number().min(1).required(),
    ieee_id: joi.number().min(1).required(),
    firstname: joi.string().min(3).pattern(/^[a-zA-Z]+$/),
    secondname: joi.string().min(3).pattern(/^[a-zA-Z]+$/).required(),
    email: joi.string().email().required(),
    username: joi.string().min(3).required(),
    gender: joi.string().min(1).max(1).required(),
  
    phone_no: joi.number().min(11),
    faculty: joi.string().min(1),
    major: joi.string().min(2),
    level: joi.string().min(2),
    birthday_date: joi.string(),
    city: joi.string().min(1).pattern(/^[a-zA-Z]+$/),
    password: joi.string().min(3).max(20).required(),
  });
  const result = uservalidate.validate({
    uni_id,
    ieee_id,
    firstname,
    secondname,
    email,
    username,
    gender,
 
    phone_no,
    faculty,
    major,
    level,
    birthday_date,
    city,
    password,
   
  });
  if (result.error) {
    console.log(result.error);
    return response.status(400).json("invalid data");
  } else {

    // check on username

    const user = await signupModel.selectOne(username)

    if (user[0] != null) {
        return response.status(400).json("invalid username")
    }

    
    knex("user")
      .insert({
        uni_id: uni_id,
        ieee_id: ieee_id,
        firstname: firstname,
        secondname: secondname,
        email: email,
        username: username,
        gender: gender,
      
        phone_no: phone_no,
        faculty: faculty,
        major: major,
        level: level,
        birthday_date: birthday_date,
        city: city,
        password: hashpassword,
        // file_name:filename,
        // file_path:path,
        // mime_type:mimetype,
      })
      .then((user) => {
        response.status(201).json(username + " you've signed up successfully");
      })
      .catch((error) => {
        response.status(201).json(error+"check your data");
      });
  }
};

const update = (request, response) => {
  const uni_id = request.body.uni_id;
  const ieee_id = request.params.ieee_id;
  const firstname = request.body.firstname;
  const secondname = request.body.secondname;
  const email = request.body.email;
  const username = request.body.username;
  const gender = request.body.gender;

  const phone_no = request.body.phone_no;
  const faculty = request.body.faculty;
  const major = request.body.major;
  const level = request.body.level;
  const birthday_date = request.body.birthday_date;
  const city = request.body.city;

  const password = request.body.password;

  knex("user")
    .update({
      uni_id: uni_id,
      ieee_id: ieee_id,
      firstname: firstname,
      secondname: secondname,
      email: email,
      username: username,
      gender: gender,
    
      phone_no: phone_no,
      faculty: faculty,
      major: major,
      level: level,
      birthday_date: birthday_date,
      city: city,

      password: password,
    })
    .where({
      ieee_id: ieee_id,
    })
    .then((user) => {
      response.status(201).json("your data has been updated");
    })
    .catch((error) => {
      console.log(error);
    });
};

const deletee = (request, response) => {
  const ieee_id = request.params.ieee_id;
  knex("user")
    .delete()
    .where({
      ieee_id: ieee_id,
    })
    .then((user) => {
      response.status(201).json("your account have been deleted");
    })
    .catch((error) => {
      console.log(error);
    });
};

exports.selectOne = async (username) => {
  const admin = await knex("user")
    .select(["username", "password"])
    .where({
      username: username,
    })
    .limit(1);

  return admin;
};

module.exports = {
  select,
  create,
  update,
  deletee,
};

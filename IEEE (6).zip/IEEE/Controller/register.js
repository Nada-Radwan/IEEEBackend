
const joi = require("joi");
const bcrypt = require("bcrypt");
const adminValidation = require("../validations/admin");
const registermodel = require("../Model/registermodel");
const jwt = require("jsonwebtoken");



const knex = require("knex")({
  client: "mysql",
  connection: {
    host: "127.0.0.1",
    port: 3306,
    user: "root",
    password: "123456",
    database: "ieee_db",
  },
});


const select = (request, response) => {
   
    knex("register")
    //.join('event', 'register.eventid','event.eventid')
    .select(["register_id","ieee_id","eventid"])
        .then((register)=>{response.status(200).json(register);})
        .catch((error)=>{console.log(error);})
        // knex("register").join('user', 'register.ieee_id','=','user.ieee_id')
        // .select(["register_id","ieee_id","eventid"])
        //     .then((register)=>{response.status(200).json(register);})
        //     .catch((error)=>{console.log(error);})
   
};

const create = async (request, response) => {
  
  const register_id = request.body.register_id;
    const ieee_id = request.body.ieee_id;
    const eventid = request.body.eventid;

    const registervalidate = joi.object({
            register_id: joi.number().min(1).required(),
            ieee_id: joi.number().min(1).required(),
            eventid: joi.number().min(1).required(),

 
  });
  const result = registervalidate.validate({
       register_id,
        ieee_id,
        eventid,
  
  });
  if (result.error) {
    console.log(result.error);
    return response.status(400).json("invalid data");
  } else {

    // check on register id
    const admin = await registermodel.selectOne(register_id)

        if (admin[0] != null) {
          return response.status(400).json("invalid  register id")
        }
       
  
        knex("register")
              .insert({
                register_id,
                ieee_id,
                eventid,
              })
              .then((register) => {
                response.status(201).json( " you've registered successfully");
              })
              .catch((error) => {
                response.status(201).json("you already registered in this event");
              });
          }
        };

   
    
   
        

        const update = (request, response) => {
                const register_id = request.body.register_id;
                const ieee_id = request.body.ieee_id;
                const eventid = request.body.eventid;
            
              knex("register")
                .update({
                   register_id: register_id,
                    ieee_id: ieee_id,
                    eventid: eventid,
                })
                .where({
                    register_id: register_id,
                })
                .then((register) => {
                  response.status(201).json("your registration has been updated");
                })
                .catch((error) => {
                  console.log(error);
                });
            };
            




            const deletee = (request, response) => {
                  const register_id = request.params.register_id;
                  knex("register")
                    .delete()
                    .where({
                      register_id: register_id,
                    })
                    .then((register) => {
                      response.status(201).json("your registration have been deleted");
                    })
                    .catch((error) => {
                      console.log(error);
                    });
                };
                
                
                
                
                
exports.selectOne = async (register_id) => {
  const admin = await knex("register")
    .select(["register_id"])
    .where({
      register_id:register_id
    })
    .limit(1);

  return admin;
};

module.exports = {
  select,
  create,
  update,
  deletee,
};

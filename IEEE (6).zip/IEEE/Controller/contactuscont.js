
const joi = require("joi");
const contactusmodel = require("../Model/contactusmodel");
const jwt = require("jsonwebtoken");



const knex = require("knex")({
  client: "mysql",
  connection: {
    host: "127.0.0.1",
    port: 3306,
    user: "root",
    password: "123456",
    database: "ieee_db",
  },
});


const select = (request, response) => {
   
    knex("contactus").select(["message_id","name","email","message"])
        .then((contactus)=>{response.status(200).json(contactus);})
        .catch((error)=>{console.log(error);})
   
};

const create = async (request, response) => {
  
  const message_id = request.body.message_id;
    const name = request.body.name;
    const email = request.body.email;
    const message = request.body.message;

    const contactusvalidate = joi.object({
            message_id: joi.number().min(1),
            name: joi.string().min(1).required(),
            email: joi.string().email().required(),
            message:joi.string().min(1).required(),

 
  });
  const result = contactusvalidate.validate({
       message_id,
        name,
        email,
        message,
  
  });
  if (result.error) {
    console.log(result.error);
    return response.status(400).json("invalid data");
  } else {

    // check on register id
    const admin = await contactusmodel.selectOne(message_id)

        if (admin[0] != null) {
          return response.status(400).json("invalid message id")
        }
       
  
        knex("contactus")
              .insert({
                message_id,
                name,
                email,
                message,
              })
              .then((register) => {
                response.status(201).json( "sent");
              })
              .catch((error) => {
                response.status(201).json("can't send this message please check your data");
              });
          }
        };

   
    
   



                
                
                
                
                
exports.selectOne = async (message_id) => {
  const admin = await knex("contactus")
    .select(["message_id"])
    .where({
      message_id:message_id
    })
    .limit(1);

  return admin;
};

module.exports = {
  select,
  create,

};

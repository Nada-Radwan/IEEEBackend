const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (eventid)=>{
    const event =  await knex('event')
    .select(['eventid'])
    .where({
        eventid:eventid,
    })
    .limit(1)

    return event
}

exports.add = async (eventid)=>{

    const event =  await knex('event')
    .insert({
       eventid,
       
    })

    return event

}
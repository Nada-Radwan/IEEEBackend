const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (message_id)=>{
    const user =  await knex('contactus')
    .select(['message_id'])
    .where({
        message_id:message_id,
    })
    .limit(1)

    return user
}

exports.add = async (message_id)=>{

    const user =  await knex('contactus')
    .insert({
        message_id,
       
    })

    return user

}
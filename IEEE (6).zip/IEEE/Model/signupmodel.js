const databaseConfig = require('../db/config/database-connection')
const knex = databaseConfig.connect()

exports.selectOne = async (username)=>{
    const user =  await knex('user')
    .select(['username'])
    .where({
        username:username,
    })
    .limit(1)

    return user
}

exports.add = async (username)=>{

    const user =  await knex('user')
    .insert({
       username,
       
    })

    return user

}
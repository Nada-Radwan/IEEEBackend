const express = require("express");
const userRouter = express.Router();

const contactuscontroller = require("../Controller/contactuscont");


userRouter.get("/", contactuscontroller.select);
userRouter.post("/", contactuscontroller.create);



module.exports = userRouter;

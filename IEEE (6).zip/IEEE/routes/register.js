const express = require("express");
const userRouter = express.Router();
const register=require("../Controller/register");


userRouter.get("/", register.select);
userRouter.post("/", register.create);
userRouter.put("/:register_id", register.update);
userRouter.delete("/:register_id",register.deletee);

 
module.exports=userRouter;
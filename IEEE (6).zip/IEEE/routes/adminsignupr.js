const express = require("express");
const userRouter = express.Router();
const bcrypt = require("bcrypt");
const admincontroller = require("../Controller/adminsignupcont");
const middleWares = require("../middelwares/auth");






userRouter.get("/", admincontroller.select);
userRouter.post("/",admincontroller.create);
userRouter.put("/:admin_id",admincontroller.update);
userRouter.delete("/:admin_id",admincontroller.deletee);

module.exports = userRouter;

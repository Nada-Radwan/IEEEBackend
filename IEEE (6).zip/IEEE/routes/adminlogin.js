const express = require("express");
const userRouter = express.Router();
const login=require("../Controller/adminlogin");


userRouter.post("/", login.login);

 
module.exports=userRouter;
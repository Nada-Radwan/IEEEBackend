const express = require("express");
const userRouter = express.Router();
const bcrypt = require("bcrypt");
const usercontroller = require("../Controller/usercontroller");
const middleWares = require("../middelwares/auth");
const trans = require("../helpers/transform");
const multer = require("multer");
const jwt = require("jsonwebtoken");

const mystorage = multer.diskStorage({
  destination: (request, file, next) => {
    //console.log("file::", file);

    next(null, "./signupuploads/");
  },
  filename: (request, file, next) => {
    const filename = trans.transform() + "-" + file.originalname;
    next(null, filename)
  },
});

const myFileFilter = (request, file, next) => {
  if (file.mimetype === "image/jpeg" || file.mimetype === "image/png") {
    next(null, true);
  } else {
    next(null, false);
  }
};

const upload = multer({
  storage: mystorage,
  limits: {
    fileSize: 1024 * 1024 * 5,
  },
  fileFilter: myFileFilter,
});

userRouter.get("/:ieee_id", usercontroller.select);
userRouter.post("/", usercontroller.create);
userRouter.put("/:ieee_id", middleWares.checkAuth, usercontroller.update);
userRouter.delete("/:ieee_id", middleWares.checkAuth, usercontroller.deletee);

module.exports = userRouter;
